# Safety series README

This README is to document AI safety issues that have not yet been addressed by the environments in the safety series.

## Possible envs
- Wireheading / Delusion Box
- IRL

## Impossible envs
- Env modifying agents (breaks the cartesian barrier)
