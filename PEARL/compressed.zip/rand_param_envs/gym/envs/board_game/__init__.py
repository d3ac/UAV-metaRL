from rand_param_envs.gym.envs.board_game.go import GoEnv
from rand_param_envs.gym.envs.board_game.hex import HexEnv
